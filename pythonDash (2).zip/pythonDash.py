from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,user, passwd, host, port, database, collection):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
#         #
#         USER = 'new_aacuser'
#         PASS = 'SNHU789'
#         HOST = 'nv-desktop-services.apporto.com'
#         PORT = 30935
#         DB = 'AAC'
#         COL = 'animals'
         
         self.user = user
         self.password = passwd
         self.host = host
         self.port = port
         self.database = database
         self.collection = collection 
#         # Initialize Connection
#         #
         self.client = MongoClient('mongodb://%s:%s@%s:%d' %
                                  (user, passwd,host,port))


         self.database = self.client['%s' % (database)]
         self.collection = self.database['%s' % (collection)]

     # for checking for class operation---helper function
    def testing(self):
        print("testing successful again")

    # method to implement Create in CRUD.
    #this method uses the insert_one method to insert a document to the animals collection
    def create(self, data):
        if data is not None:
            # data should be dictionary
            #insert data into the database here
            return self.database.animals.insert_one(data)
            
        else:
            #error message thrown if data is None
            raise Exception("Nothing to save, because data parameter is empty")

    # method to implement the Read in CRUD.
    #the find method could be used to read data or documents in the animals collection
    def read(self, query_filter):
        if query_filter is not None:
            #query_filter is usually a dictionary with items or an empty dictionary
            return self.database.animals.find(query_filter)

        else:
            #error message thrown if query_filter is None
            raise TypeError("Query filter cannot be none")
            
    #update method of crUd
    #implemented using update_many
    def update(self,filterQuery,newUpdate):
        #filterQuery is the query pointing to the document to update
        #newUpdate is the update
        if newUpdate is not None:
            return self.database.animals.update_many(filterQuery,newUpdate)
             
        else:
            #error message thrown if there is nothing to update
            raise Exception("Update string  is missing")
            
            
   #delete method of cruD
    def delete(self,data_to_delete):
        #data_to_delete is the query that points to the document to delete
        if data_to_delete is not None:
            return self.database.animals.delete_many(data_to_delete)
         
        #no data to delete
        #error message thrown if data_to_delete is None
        else: raise Exception("Nothing to delete")
            
           
            




